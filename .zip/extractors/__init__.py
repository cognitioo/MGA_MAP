"""Extractors package for document data extraction"""
from extractors.document_data_extractor import DocumentDataExtractor, extract_data_from_upload
